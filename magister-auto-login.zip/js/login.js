const d = document.getElementById.bind(document);

// user object moet gemaakt worden vanuit browser.storage.sync

var snooze = ms => new Promise(res => setTimeout(res, ms));
function login() {
    browser.storage.sync.get(['number', 'password'], async function (result) {
        console.log(result);
        
        await waitForSel("username");

        if (d("username") && result.number) {
            d("username").value = result.number;
            d("username").dispatchEvent(new Event("input"));
        };

        await waitForSel("username_submit")
        if (d("username_submit")) {
            d("username_submit").click();
        };

        await waitForSel("rswp_password")

        if (d("rswp_password") && result.password) {
            d("rswp_password").value = result.password;
            d("rswp_password").dispatchEvent(new Event("input"));
        };

        await waitForSel("rswp_submit")
        if (d("rswp_submit")) {
            d("rswp_submit").click();
        };
    });
}

function waitForSel(s) {
    return new Promise(res => {
        setInterval(() => {
            if (d(s)) {
                res()
            }
        }, 10);
    });
};

browser.storage.sync.get(['enabled'], function (result){
    if(result.enabled){
        login();
    };
});



